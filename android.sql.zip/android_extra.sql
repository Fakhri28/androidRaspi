
--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_paket`
--
ALTER TABLE `data_paket`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_paket`
--
ALTER TABLE `data_paket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
