
-- --------------------------------------------------------

--
-- Struktur dari tabel `data_paket`
--

CREATE TABLE `data_paket` (
  `id` int(11) NOT NULL,
  `nama_penerima` varchar(50) NOT NULL,
  `no_resi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Potong tabel sebelum dimasukkan `data_paket`
--

TRUNCATE TABLE `data_paket`;
--
-- Dumping data untuk tabel `data_paket`
--

INSERT INTO `data_paket` (`id`, `nama_penerima`, `no_resi`) VALUES
(1, 'fakhri', 'jdaowd201'),
(2, 'aku', 'sisau29'),
(3, 'fakhriali', 'ajsdn199'),
(4, 'fakhriali', 'ajsdn199'),
(5, 'mohammad ali fakhri', 'jkawsiu219'),
(6, 'mohammad ali fakhri', 'jkawsiu219'),
(7, 'adelia moudy carolina', 'jkaw12719');
